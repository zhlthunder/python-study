#!/usr/bin/env python
# -*- coding: utf-8 -*-

def table_process():
    import os,sys
    from blog.models import ethernet,fccard,disk,raid,nvme,cpu,memory

     ##cpu
    cc=cpu.objects.all()
    for line in cc:
        obj=line.asset_db_set.all()
        if not obj:
            line.delete()
   ##memory
    mm=memory.objects.all()
    for line in mm:
        obj=line.asset_db_set.all()
        if not obj:
            line.delete()

    ##ethernet
    ee=ethernet.objects.all()
    for line in ee:
        obj=line.asset_db_set.all()
        if not obj:
            line.delete()


    ##fccard
    fc=fccard.objects.all()
    for line in fc:
        obj=line.asset_db_set.all()
        if not obj:
            line.delete()

    ##disk
    dd=disk.objects.all()
    for line in dd:
        obj=line.asset_db_set.all()
        if not obj:
            line.delete()

    ##raid
    rr=raid.objects.all()
    for line in rr:
        obj=line.asset_db_set.all()
        if not obj:
            line.delete()
    ##nvme
    nn=nvme.objects.all()
    for line in nn:
        obj=line.asset_db_set.all()
        if not obj:
            line.delete()

if __name__ == '__main__':
    import os,sys
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "csvt02.settings")
    from django.core.management import execute_from_command_line
    execute_from_command_line(sys.argv)
    table_process()