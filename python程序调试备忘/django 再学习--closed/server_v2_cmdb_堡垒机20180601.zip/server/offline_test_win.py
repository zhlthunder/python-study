#!/usr/bin/env python
# -*- coding: utf-8 -*-
import  winrm
ip='192.198.20.14'
username='administrator'
passwd='password'

# ip='127.0.0.1'
# username='administrator'
# passwd='Root123'

cmd='python C:\client_collect\client.py'
# cmd="sas3ircu-win 0 display"

conn=winrm.Session('http://'+ip+':5985/wsman',auth=(username,passwd))
r=conn.run_cmd(cmd,)
# print(r)
ret=r.std_out.decode()
print(ret)
print(type(ret))
# result=eval(ret)
# print(result)
# print(type(result))