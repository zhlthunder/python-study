#!/usr/bin/python 
import paramiko
import threading
import time

def ssh2(ip,username,passwd,cmd,li):
    try:
        # print(cmd)
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(ip,22,username,passwd,timeout=5)
        stdin, stdout, stderr = ssh.exec_command(cmd)
        li.append(stdout.read())
        # print '%s\tOK\n'%(ip)
        ssh.close()
        # print(li)
        return li
    except :
        # print '%s\tError\n'%(ip)
        pass

if __name__=='__main__':
# comman list
    result=[]
    # cmd = ['lsblk','ifconfig',"storcli show | grep '^ \\{0,2\\}[0-9]'|awk '{print $2}'&&sas3ircu 0 display | grep -i 'controller type'|awk '{print $NF}'"]
    #cmd = ['lsblk','ifconfig',"route"]
    cmd="python /root/client_collect/client.py"
    username = "root"  
    passwd = "123456"   
    threads = [6] 
    # print "Begin......"
    ip="128.1.2.201"
    a=threading.Thread(target=ssh2,args=(ip,username,passwd,cmd,result))
    a.start()
    a.join()
    # time.sleep(1)
    result=result[0]
    print(result)
    print(type(result))
    result=eval(result)
    # print(result)
    print(type(result))


    # for i in result:
    #     print i,
  
