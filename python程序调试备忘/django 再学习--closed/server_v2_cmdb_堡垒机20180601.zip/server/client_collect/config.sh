#!/bin/bash


#rpm -ivh sg3_utils-1.37-5.el7.x86_64.rpm --nodeps
chmod +x /root/client_collect/sas3ircu-linux /root/client_collect/storcli-linux /root/client_collect/arcconf-linux
rm -rf /usr/bin/sas3ircu
rm -rf /usr/bin/storcli
rm -rf /usr/bin/arcconf

ln -s /root/client_collect/sas3ircu-linux /usr/bin/sas3ircu
ln -s /root/client_collect/storcli-linux /usr/bin/storcli
ln -s /root/client_collect/arcconf-linux /usr/bin/arcconf



