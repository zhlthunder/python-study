#!/usr/bin/env python
# -*- coding: utf-8 -*-

class Myprocess(object):
    # def __init__(self): #fist time request, call one time
        # print("call on first time request")
        # from table_process_offline import table_process
        # table_process()

    def process_request(self,request):
        from table_process_offline import table_process
        table_process()
    #
    # def prcocess_view(self,request):
    #     print("aaa")
    # def process_response(self,response):
    #     from table_process_offline import table_process
    #     table_process()
    #     return response