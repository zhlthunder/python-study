#!/usr/bin/env python
# -*- coding: utf-8 -*-

import paramiko,sys

def uploadd(ip,user,passwd,file_info):
    transport = paramiko.Transport((ip,22))
    transport.connect(username=user,password=passwd)

    sftp = paramiko.SFTPClient.from_transport(transport)
    # 将location.py 上传至服务器 /tmp/test.py
    filename=file_info.split('/')[-1]

    sftp.put(file_info, '/root/'+filename)
    # 将remove_path 下载到本地 local_path
    # sftp.get('/tmp/yum.log', 'C:/yum.log')
    # print('aaaaa')

    transport.close()

if __name__ == '__main__':
    ip='128.1.2.201'
    user='root'
    passwd='123456'
    file_info='C:/temp.txt'
    uploadd(ip,user,passwd,file_info)
