#!/usr/bin/env python
# -*- coding: utf-8 -*-
import  winrm

def winrmm(ip,username,passwd,cmd):
    conn=winrm.Session('http://'+ip+':5985/wsman',auth=(username,passwd))
    r=conn.run_cmd(cmd,)
    # print(r)
    ret=r.std_out.decode()
    return ret

if __name__ == '__main__':
    ip='127.0.0.1'
    username='administrator'
    passwd='Root123'
    cmd='dir'
    ret=winrmm(ip,username,passwd,cmd)
    print(ret)

