from django.conf.urls import patterns, include, url
from django.contrib.auth.views import login,logout_then_login
import settings

# from blog import rest_urls

# Uncomment the next two lines to enable the admin:
from django.contrib import admin
admin.autodiscover()


urlpatterns = patterns('',
    # Examples:
    # url(r'^$', 'csvt02.views.home', name='home'),
    # url(r'^csvt02/', include('csvt02.foo.urls')),

    # Uncomment the admin/doc line below to enable admin documentation:
    # url(r'^admin/doc/', include('django.contrib.admindocs.urls')),

    # Uncomment the next line to enable the admin:
    url(r'^admin/', include(admin.site.urls)),
    url(r'^accounts/login/$',login,{'template_name':'index.html'}),
    url(r'^login/$','blog.views.login_accounts'),
    url(r'^logout/$',logout_then_login),
    url(r'^$','blog.views.login_accounts'),

    url(r'^monitor/(?P<page>[0-9]+)/$','blog.views.hdd_disk',{'temple':'disk_feature/hdd.html'}),
    url(r'^monitor_s/(?P<page>[0-9]+)/$','blog.views.hdd_disk',{'temple':'disk_feature/hdd_s.html'}),
    url(r'^search/$','blog.views.hdd_search',{'temple':'disk_feature/hdd_search.html'}),
    url(r'^search_s/$','blog.views.hdd_search',{'temple':'disk_feature/hdd_search_s.html'}),
    url(r'^nvme_m/(?P<page>[0-9]+)/$','blog.views.nvme',{'temple':'disk_feature/nvme.html'}),
    url(r'^nvme_m_s/(?P<page>[0-9]+)/$','blog.views.nvme',{'temple':'disk_feature/nvme_s.html'}),
    url(r'^nvme_m_ss/(?P<page>[0-9]+)/$','blog.views.nvme',{'temple':'disk_feature/nvme_ss.html'}),
    url(r'^nvme_search_s/$','blog.views.nvme_search',{'temple':'disk_feature/nvme_search_s.html'}),
    url(r'^nvme_search_ss/$','blog.views.nvme_search',{'temple':'disk_feature/nvme_search_ss.html'}),
    url(r'^nvme_search/$','blog.views.nvme_search',{'temple':'disk_feature/nvme_search.html'}),

    url(r'^cmcc_material/(?P<page>[0-9]+)/$','blog.views.cmcc_material'),
    url(r'^cmcc_search/$','blog.views.cmcc_search'),
    url(r'^Disk_res/$','blog.views.disk_res'),
    url(r'^disk_res_s/$','blog.views.disk_res_s'),


    url(r'^asset/$','blog.views.asset'),

    #for cmdb
    url(r'^submit_asset/$','blog.views.submit_asset'),
    url(r'^asset_db_show/$','blog.views.asset_db_show'),
    url(r'^ethernet/detail/(?P<nid>\d+)/$','blog.views.asset_db_detail',{'temple':'cmdb/ethernet.html','mm':'ethernet'}),
    url(r'^fccard/detail/(?P<nid>\d+)/$','blog.views.asset_db_detail',{'temple':'cmdb/fccard.html','mm':'fccard'}),
    url(r'^disk/detail/(?P<nid>\d+)/$','blog.views.asset_db_detail',{'temple':'cmdb/disk.html','mm':'disk'}),
    url(r'^raid/detail/(?P<nid>\d+)/$','blog.views.asset_db_detail',{'temple':'cmdb/raid.html','mm':'raid'}),
    url(r'^nvme/detail/(?P<nid>\d+)/$','blog.views.asset_db_detail',{'temple':'cmdb/nvme.html','mm':'nvme'}),
    url(r'^cpu/detail/(?P<nid>\d+)/$','blog.views.asset_db_detail',{'temple':'cmdb/cpu.html','mm':'cpu'}),
    url(r'^memory/detail/(?P<nid>\d+)/$','blog.views.asset_db_detail',{'temple':'cmdb/memory.html','mm':'memory'}),
    url(r'^asset_db_update/$','blog.views.asset_db_update'),
    url(r'^asset_search/$','blog.views.asset_search'),
    url(r'^sub/(?P<serversn>\S+)/$','blog.views.asset_sub'),
    url(r'^jumper/$','blog.views.jumper_main'),
    url(r'^jumper_file/$','blog.views.jumper_file'),
    url(r'^jumper_term/(?P<serverinfo>\S+)/$','blog.views.jumper_term'),

    # url(r'^api/', include(rest_urls) ),



   
)
