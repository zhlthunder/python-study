from django.db import models

class Disk_resource(models.Model):
	Model=models.CharField(max_length=80)
	inch=models.CharField(max_length=30)
	Qty=models.CharField(max_length=30)
	BOX_NO=models.CharField(max_length=30)
	Capacity=models.CharField(max_length=30)
	Interface=models.CharField(max_length=30)
	
	def __unicode__(self):
		return self.Model

class material_type(models.Model):
	typename=models.CharField(max_length=100)
	
	def __unicode__(self):
		return self.typename

class cmcc_material_tracking(models.Model):
	date=models.DateField()
	model=models.CharField(max_length=200)
	serial=models.CharField(max_length=200)
	type=models.ForeignKey('material_type')
	qty=models.CharField(max_length=30)
	wherefrom=models.CharField(max_length=150)
	location=models.CharField(max_length=150,null=True,blank=True)
	status=models.CharField(max_length=150,null=True,blank=True)
	desc1=models.CharField(max_length=150,null=True,blank=True)
	desc2=models.CharField(max_length=150,null=True,blank=True)
	desc3=models.CharField(max_length=150,null=True,blank=True)
	desc4=models.CharField(max_length=150,null=True,blank=True)
	
	def __unicode__(self):
		return self.model

class cmcc_internal_borrow(models.Model):
	STATUS=(
	('00','running'),
	('01','complete'),
	)
	date=models.DateField()
	model=models.CharField(max_length=200)
	serial=models.CharField(max_length=200)
	Borrower=models.CharField(max_length=30)
	qty=models.CharField(max_length=30)
	return_date=models.CharField(max_length=30)
	status=models.CharField(max_length=30,choices=STATUS)
	
	def __unicode__(self):
		return self.model

class Disk_borrow(models.Model):
	Borrow_date=models.CharField(max_length=80)
	Borrower=models.CharField(max_length=30)
	Model=models.CharField(max_length=30)
	QTY=models.CharField(max_length=30)
	Return_date=models.CharField(max_length=30)
	
	def __unicode__(self):
		return self.Model

class Server_db(models.Model):
	name=models.CharField(max_length=30)
	ip_addr=models.CharField(max_length=30)
	user=models.CharField(max_length=30)
	passwd=models.CharField(max_length=30)
	cpu_s=models.CharField(max_length=30,null=True,blank=True)
	cpu=models.CharField(max_length=30,null=True,blank=True)
	memory_s=models.CharField(max_length=400,null=True,blank=True)
	memory=models.CharField(max_length=400,null=True,blank=True)
	ethernet_s=models.CharField(max_length=80,null=True,blank=True)
	ethernet=models.CharField(max_length=80,null=True,blank=True)
	disk_s=models.CharField(max_length=400,null=True,blank=True)
	disk=models.CharField(max_length=400,null=True,blank=True)
	raid_s=models.CharField(max_length=30,null=True,blank=True)
	raid=models.CharField(max_length=30,null=True,blank=True)
	nvme_s=models.CharField(max_length=30,null=True,blank=True)
	nvme=models.CharField(max_length=30,null=True,blank=True)
	des1_s=models.CharField(max_length=30,null=True,blank=True)
	des1=models.CharField(max_length=30,null=True,blank=True)
	des2_s=models.CharField(max_length=30,null=True,blank=True)
	des2=models.CharField(max_length=30,null=True,blank=True)
	status=models.CharField(max_length=30,null=True,blank=True)

	def __unicode__(self):
		return self.name

class Disk_info(models.Model):  ##for hdd feature test result
	bw_num_r=models.CharField(max_length=30,null=True,blank=True)
	bw_idp_r=models.CharField(max_length=30,null=True,blank=True)
	bw_r_spec=models.CharField(max_length=30,null=True,blank=True)
	bw_num_w=models.CharField(max_length=30,null=True,blank=True)
	bw_idp_w=models.CharField(max_length=30,null=True,blank=True)
	bw_w_spec=models.CharField(max_length=30,null=True,blank=True)
	io_num_r=models.CharField(max_length=30,null=True,blank=True)
	io_idp_r=models.CharField(max_length=30,null=True,blank=True)
	iops_r_spec=models.CharField(max_length=30,null=True,blank=True)
	io_num_w=models.CharField(max_length=30,null=True,blank=True)
	io_idp_w=models.CharField(max_length=30,null=True,blank=True)
	iops_w_spec=models.CharField(max_length=30,null=True,blank=True)
	disk_cache=models.CharField(max_length=30,null=True,blank=True)
	t_date=models.CharField(max_length=100,null=True,blank=True)
	d_model=models.CharField(max_length=30,null=True,blank=True)
	d_vendor=models.CharField(max_length=30,null=True,blank=True)
	d_capacity=models.CharField(max_length=30,null=True,blank=True)
	d_firmware=models.CharField(max_length=30,null=True,blank=True)
	d_inch=models.CharField(max_length=30,null=True,blank=True)
	d_interface=models.CharField(max_length=30,null=True,blank=True)
	d_medium=models.CharField(max_length=30,null=True,blank=True)
	d_sector=models.CharField(max_length=30,null=True,blank=True)
	d_rotarate=models.CharField(max_length=30,null=True,blank=True)
	d_speed=models.CharField(max_length=30,null=True,blank=True)
	rd_model=models.CharField(max_length=30,null=True,blank=True)
	rd_firmware=models.CharField(max_length=30,null=True,blank=True)
	vol_type=models.CharField(max_length=30,null=True,blank=True)
	seq_r_bw=models.CharField(max_length=30,null=True,blank=True)
	seq_w_bw=models.CharField(max_length=30,null=True,blank=True)
	rand_r_iops=models.CharField(max_length=30,null=True,blank=True)
	rand_w_iops=models.CharField(max_length=30,null=True,blank=True)
	sn=models.CharField(max_length=30,null=True,blank=True)
	d_health=models.CharField(max_length=30,null=True,blank=True)
	#d_hide=models.CharField(max_length=10,null=True,blank=True)

	def __unicode__(self):
		return self.d_model

class Nvme_ssd_db(models.Model): # for nvme feature test result
	bw_num=models.CharField(max_length=30,null=True,blank=True)
	bw_idp=models.CharField(max_length=30,null=True,blank=True)
	io_num=models.CharField(max_length=30,null=True,blank=True)
	io_idp=models.CharField(max_length=30,null=True,blank=True)
	lant_num=models.CharField(max_length=30,null=True,blank=True)
	lant_idp=models.CharField(max_length=30,null=True,blank=True)
	seq_r_bw_spec=models.CharField(max_length=30,null=True,blank=True)
	seq_w_bw_spec=models.CharField(max_length=30,null=True,blank=True)
	rand_r_iops_4k_spec=models.CharField(max_length=30,null=True,blank=True)
	rand_w_iops_4k_spec=models.CharField(max_length=30,null=True,blank=True)
	rand_r_iops_8k_spec=models.CharField(max_length=30,null=True,blank=True)
	rand_w_iops_8k_spec=models.CharField(max_length=30,null=True,blank=True)
	rand_rw_iops_4k_spec=models.CharField(max_length=30,null=True,blank=True)
	rand_rw_iops_8k_spec=models.CharField(max_length=30,null=True,blank=True)
	seq_r_lat_4k_spec=models.CharField(max_length=30,null=True,blank=True)
	seq_w_lat_4k_spec=models.CharField(max_length=30,null=True,blank=True)
	rand_r_lat_4k_spec=models.CharField(max_length=30,null=True,blank=True)
	rand_w_lat_4k_spec=models.CharField(max_length=30,null=True,blank=True)	
	t_date=models.CharField(max_length=30,null=True,blank=True)     
        nvme_interface=models.CharField(max_length=30,null=True,blank=True)
	n_model=models.CharField(max_length=30,null=True,blank=True)
        n_vendor=models.CharField(max_length=30,null=True,blank=True)
        n_sn=models.CharField(max_length=30,null=True,blank=True)
        n_fw=models.CharField(max_length=30,null=True,blank=True)
        n_cap=models.CharField(max_length=30,null=True,blank=True)
        seq_r_bw=models.CharField(max_length=30,null=True,blank=True)
        seq_w_bw=models.CharField(max_length=30,null=True,blank=True)
	rand_r_iops_4k=models.CharField(max_length=30,null=True,blank=True)
	rand_w_iops_4k=models.CharField(max_length=30,null=True,blank=True)      	
	rand_r_iops_8k=models.CharField(max_length=30,null=True,blank=True)
	rand_w_iops_8k=models.CharField(max_length=30,null=True,blank=True)    		
	rand_rw_iops_4k=models.CharField(max_length=30,null=True,blank=True)
	rand_rw_iops_8k=models.CharField(max_length=30,null=True,blank=True)
	seq_r_lat_4k=models.CharField(max_length=30,null=True,blank=True)
	seq_w_lat_4k=models.CharField(max_length=30,null=True,blank=True)		
	rand_r_lat_4k=models.CharField(max_length=30,null=True,blank=True)
	rand_w_lat_4k=models.CharField(max_length=30,null=True,blank=True)		
	n_health=models.CharField(max_length=30,null=True,blank=True)
	rand_r_iops_4k_cc_spec=models.CharField(max_length=30,null=True,blank=True)	
	rand_r_iops_4k_cc=models.CharField(max_length=30,null=True,blank=True)	
	rand_w_iops_4k_cc_spec=models.CharField(max_length=30,null=True,blank=True)	
	rand_w_iops_4k_cc=models.CharField(max_length=30,null=True,blank=True)

##for cmdb models

class cpu(models.Model):
	cpu_model=models.CharField(max_length=100,null=True,blank=True)
	cpu_maker=models.CharField(max_length=100,null=True,blank=True)
	cpu_frequency=models.CharField(max_length=100,null=True,blank=True)
	cpu_tdp=models.CharField(max_length=100,null=True,blank=True)
	cpu_cores=models.CharField(max_length=200,null=True,blank=True)
	cpu_threads=models.CharField(max_length=200,null=True,blank=True)
	cpu_remark=models.CharField(max_length=200,null=True,blank=True)
	cpu_remark2=models.CharField(max_length=200,null=True,blank=True)
	cpu_remark3=models.CharField(max_length=200,null=True,blank=True)
	cpu_remark4=models.CharField(max_length=200,null=True,blank=True)

	def __unicode__(self):
		return self.cpu_model


class memory(models.Model):
	mm_pn=models.CharField(max_length=100,null=True,blank=True)
	mm_sn=models.CharField(max_length=100,null=True,blank=True)
	mm_frequency=models.CharField(max_length=100,null=True,blank=True)
	mm_capacity=models.CharField(max_length=100,null=True,blank=True)
	mm_maker=models.CharField(max_length=200,null=True,blank=True)
	mm_slot=models.CharField(max_length=200,null=True,blank=True)
	mm_remark=models.CharField(max_length=200,null=True,blank=True)
	mm_remark2=models.CharField(max_length=200,null=True,blank=True)
	mm_remark3=models.CharField(max_length=200,null=True,blank=True)
	mm_remark4=models.CharField(max_length=200,null=True,blank=True)

	def __unicode__(self):
		return self.mm_pn

class ethernet(models.Model):
	TT=(
	('00','Optical'),
	('01','Electrical'),
	)
	e_model=models.CharField(max_length=50,null=True,blank=True)
	e_sn=models.CharField(max_length=50,null=True,blank=True)
	e_fw=models.CharField(max_length=50,null=True,blank=True)
	e_maker=models.CharField(max_length=50,null=True,blank=True)
	e_portnum=models.CharField(max_length=50,null=True,blank=True)
	e_porttype=models.CharField(max_length=50,null=True,blank=True,choices=TT)
	e_qty=models.CharField(max_length=50,null=True,blank=True)
	e_slot=models.CharField(max_length=50,null=True,blank=True)
	e_remark=models.CharField(max_length=50,null=True,blank=True)
	e_remark2=models.CharField(max_length=50,null=True,blank=True)
	e_remark3=models.CharField(max_length=50,null=True,blank=True)

	def __unicode__(self):
		return self.e_model

class fccard(models.Model):
	f_model=models.CharField(max_length=50,null=True,blank=True)
	f_sn=models.CharField(max_length=50,null=True,blank=True)
	f_fw=models.CharField(max_length=50,null=True,blank=True)
	f_maker=models.CharField(max_length=50,null=True,blank=True)
	f_portnum=models.CharField(max_length=50,null=True,blank=True)
	f_qty=models.CharField(max_length=50,null=True,blank=True)
	f_remark=models.CharField(max_length=200,null=True,blank=True)
	f_remark2=models.CharField(max_length=200,null=True,blank=True)
	f_remark3=models.CharField(max_length=200,null=True,blank=True)
	f_remark4=models.CharField(max_length=200,null=True,blank=True)

	def __unicode__(self):
		return self.f_model

class disk(models.Model):
	TT=(
	('00','SAS HDD'),
	('01','SATA HDD'),
	('02','SAS SSD'),
	('03','SATA SSD'),
	)
	d_model=models.CharField(max_length=50,null=True,blank=True)
	d_fw=models.CharField(max_length=50,null=True,blank=True)
	d_maker=models.CharField(max_length=50,null=True,blank=True)
	d_type=models.CharField(max_length=50,null=True,blank=True,choices=TT)
	d_qty=models.CharField(max_length=50,null=True,blank=True)
	d_slot=models.CharField(max_length=200,null=True,blank=True)
	d_sn=models.CharField(max_length=200,null=True,blank=True)
	d_remark=models.CharField(max_length=200,null=True,blank=True)
	d_remark2=models.CharField(max_length=200,null=True,blank=True)
	d_remark3=models.CharField(max_length=200,null=True,blank=True)
	d_remark4=models.CharField(max_length=200,null=True,blank=True)

	def __unicode__(self):
		return self.d_model

class raid(models.Model):
	r_model=models.CharField(max_length=50,null=True,blank=True)
	r_sn=models.CharField(max_length=50,null=True,blank=True)
	r_fw=models.CharField(max_length=50,null=True,blank=True)
	r_maker=models.CharField(max_length=50,null=True,blank=True)
	r_cache=models.CharField(max_length=200,null=True,blank=True)
	r_bbu=models.CharField(max_length=200,null=True,blank=True)
	r_remark=models.CharField(max_length=200,null=True,blank=True)
	r_remark2=models.CharField(max_length=200,null=True,blank=True)
	r_remark3=models.CharField(max_length=200,null=True,blank=True)
	r_remark4=models.CharField(max_length=200,null=True,blank=True)

	def __unicode__(self):
		return self.r_model

class nvme(models.Model):
	n_model=models.CharField(max_length=50,null=True,blank=True)
	n_sn=models.CharField(max_length=50,null=True,blank=True)
	n_fw=models.CharField(max_length=50,null=True,blank=True)
	n_maker=models.CharField(max_length=50,null=True,blank=True)
	n_qty=models.CharField(max_length=50,null=True,blank=True)
	n_remark=models.CharField(max_length=200,null=True,blank=True)
	n_remark2=models.CharField(max_length=200,null=True,blank=True)
	n_remark3=models.CharField(max_length=200,null=True,blank=True)
	n_remark4=models.CharField(max_length=200,null=True,blank=True)

	def __unicode__(self):
		return self.n_model

class asset_db(models.Model):
	serverno=models.CharField(max_length=50)
	ip_addr=models.CharField(max_length=50)
	user=models.CharField(max_length=50)
	passwd=models.CharField(max_length=50)
	owner=models.CharField(max_length=50,null=True,blank=True)
	cpus=models.ManyToManyField(cpu,null=True,blank=True)
	memorys=models.ManyToManyField(memory,null=True,blank=True)
	ethernets=models.ManyToManyField(ethernet,null=True,blank=True)
	fccards=models.ManyToManyField(fccard,null=True,blank=True)
	disks=models.ManyToManyField(disk,null=True,blank=True)
	raids=models.ManyToManyField(raid,null=True,blank=True)
	nvmes=models.ManyToManyField(nvme,null=True,blank=True)
	status=models.CharField(max_length=30,null=True,blank=True)
	remark=models.CharField(max_length=30,null=True,blank=True)  ##for update_time
	remark2=models.CharField(max_length=30,null=True,blank=True)  ##for test
	remark3=models.CharField(max_length=30,null=True,blank=True) ##for os_type


	def __unicode__(self):
		return self.serverno

##########################
