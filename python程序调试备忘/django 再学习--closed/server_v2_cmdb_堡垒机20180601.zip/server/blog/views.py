#_*_ coding:UTF-8 _*_
import re,os,random,string,sys
from django.http import HttpResponse,HttpResponseRedirect
from django import forms
from django.shortcuts import render_to_response
from blog.models import *
from django.contrib import auth
from django.contrib.auth.decorators import login_required
# from p_ssh_expect import ssh2
from p_ssh_expect_multi import ssh2
import time,datetime
import threading
# import verify_code
from django.core.cache import cache
from csvt02 import settings
import paramiko,json
import winrm
import datetime
# from django.core import serializers
from ssh_client import ssh22
from winrm_client import winrmm
from sftp_client import uploadd

def login_accounts(request):
	username=request.POST.get('username')
	password=request.POST.get('password')
	#print request.user
	user=auth.authenticate(username=username,password=password)
	if user is not None:
		auth.login(request,user)
		#print request.user
		# return HttpResponseRedirect("/monitor/1/")
		return HttpResponseRedirect("/asset_db_show/")
	else:
		return render_to_response('index.html',{'login_err':"Wrong username and password!"})

def get_pages(objj):
	num=divmod(objj.objects.filter().count(),12)
	if num[1]!=0:
			pages=num[0]+1
	else:
			pages=num[0]
	return pages

@login_required
def hdd_disk(request,page,temple):
        page=int(page)
        pages=[x for x in range(1,get_pages(Disk_info)+1)]
        end=pages[-1]
        content_list=Disk_info.objects.filter()[(page-1)*12:page*12]
        # print page
        # print content_list

        if get_pages(Disk_info)>1:
                return render_to_response(temple,{'disk_info':content_list,'pages':pages,'end':end,'page':page,'errmsg':'OK'})
        else:
                return render_to_response(temple,{'disk_info':content_list,'pages':pages,'end':end,'errmsg':'faile'})

@login_required
def nvme(request,page,temple):
        page=int(page)
        pages=[x for x in range(1,get_pages(Nvme_ssd_db)+1)]
        end=pages[-1]
        content_list=Nvme_ssd_db.objects.filter()[(page-1)*12:page*12]
        # print page
        # print content_list

        if get_pages(Nvme_ssd_db)>1:
                return render_to_response(temple,{'nvme_info':content_list,'pages':pages,'end':end,'page':page,'errmsg':'OK'})
        else:
                return render_to_response(temple,{'nvme_info':content_list,'pages':pages,'end':end,'errmsg':'faile'})

@login_required
def hdd_search(request,temple):
	# print request.GET
	# print request.POST
	tt=request.POST.get('model')
	tu=request.POST.get('interface')
	tv=request.POST.get('rotarate')
	tw=request.POST.get('capacity')
	tp=request.POST.get('vendor')
	tb=request.POST.get('inch')
	kwargs={ }
	if tt is not None:
		kwargs['d_model__contains']=tt.upper()
	if tu is not None:
		kwargs['d_interface__contains']=tu.upper()
	if tv is not None:
		kwargs['d_rotarate__contains']=tv.upper()
	if tw is not None:
		kwargs['d_capacity__contains']=tw.upper()
	if tp is not None:
		kwargs['d_vendor__contains']=tp.upper()
	if tb is not None:
		kwargs['d_inch__contains']=tb.upper()
		content_list=Disk_info.objects.filter(**kwargs)
		#content_list=Disk_info.objects.filter(d_model__contains=tt)
		return render_to_response(temple,{'disk_info':content_list})

@login_required
def nvme_search(request,temple):
	print(request.GET)
	print(request.POST)
	tt=request.POST.get('model')
	tp=request.POST.get('t_date')
	kwargs={ }
	if tt is not None:
		kwargs['n_model__contains']=tt.upper()
	if tp is not None:
		kwargs['t_date__contains']=tp.upper()
		content_list=Nvme_ssd_db.objects.filter(**kwargs)
		return render_to_response(temple,{'nvme_info':content_list})


##cmcc_material page
@login_required
def cmcc_material(request,page):
	page=int(page)
	pages=[x for x in range(1,get_pages(cmcc_material_tracking)+1)]
	end=pages[-1]
	content_list=cmcc_material_tracking.objects.filter()[(page-1)*12:page*12]
	print(page)
	print(content_list)

	if get_pages(cmcc_material_tracking)>1:
			return render_to_response('resource_manage/cmcc_material.html',{'cmcc_info':content_list,'pages':pages,'end':end,'page':page,'errmsg':'OK'})
	else:
			return render_to_response('resource_manage/cmcc_material.html',{'cmcc_info':content_list,'pages':pages,'end':end,'errmsg':'fail'})

@login_required
def cmcc_search(request):
	tt=request.POST.get('model')
	ta=request.POST.get('serial')
	tb=request.POST.get('type')
	kwargs={ }
	if tt is not None:
		kwargs['model__contains']=tt.upper()
	if ta is not None:
		kwargs['serial__contains']=ta.upper()
	if tb is not None:
		kwargs['type__typename__icontains']=tb
	content_list=cmcc_material_tracking.objects.filter(**kwargs)
	return render_to_response('resource_manage/cmcc_search.html',{'cmcc_info':content_list})
#######################

##disk mange internally
@login_required
def disk_res(request):
	ss=Disk_resource.objects.all()
	return render_to_response('resource_manage/disk_res.html',{'ss':ss})

@login_required
def disk_res_s(request):
	print(request.GET)
	print(request.POST)
	tt=request.POST.get('model')
	tm=request.POST.get('interface')
	tn=request.POST.get('capacity')
	kwargs={ }
	if tt is not None:
			kwargs['Model__contains']=tt.upper()
	if tm is not None:
			kwargs['Interface__contains']=tm.upper()
	if tn is not None:
			kwargs['Capacity__contains']=tn.upper()
	ss=Disk_resource.objects.filter(**kwargs)
	return render_to_response('resource_manage/disk_res_s.html',{'ss':ss})
#######################





##for cmdb using

@login_required
def asset_db_show(request):
	val=request.session.get('key',None)
	sw=''
	if not val:
		ss=asset_db.objects.all()
	else:
		kwargs={ }
		if val is not None:
			kwargs['serverno__icontains']=val.upper()
			ss=asset_db.objects.filter(**kwargs)
			del  request.session['key']
			sw='1'
	return render_to_response('cmdb/asset_db.html',{'ss':ss,'sw':sw})

@login_required
def asset_search(request):
	tt=request.POST.get('ServerNo')
	request.session['key']=tt
	kwargs={ }
	if tt is not None:
		kwargs['serverno__icontains']=tt.upper()
	content_list=asset_db.objects.filter(**kwargs)
	return render_to_response('cmdb/asset_db.html',{'ss':content_list,'sw':'1'})


@login_required
def submit_asset(request):
	if request.method=='POST':
		ip=request.POST.get('ip')
		serverno=request.POST.get('serverno')
		user=request.POST.get('user')
		passwd=request.POST.get('passwd')
		owner=request.POST.get('owner')
		# print(ip,user,passwd)
		##insert into db base
		asset_db.objects.create(serverno=serverno,ip_addr=ip,user=user,passwd=passwd,status='Online',owner=owner)
		return HttpResponseRedirect('/asset_db_show/')

	return render_to_response('cmdb/submit_asset.html')


@login_required()
def asset_sub(request,serversn):
	if request.method=='POST':
		ip=request.POST.get('ip')
		serverno=request.POST.get('serverno')
		user=request.POST.get('user')
		passwd=request.POST.get('passwd')
		owner=request.POST.get('owner')
		task=request.POST.get('task')
		print(task)
		print(type(task))
		asset_db.objects.filter(serverno=serversn).update(serverno=serverno,ip_addr=ip,user=user,passwd=passwd,status='Online',owner=owner,remark2=task)
		return HttpResponseRedirect('/asset_db_show/')


	else:
		ss=asset_db.objects.get(serverno=serversn)
		print(ss)
		return render_to_response("cmdb/submit_asset.html",{'ss':ss})


@login_required
def asset_db_detail(request,temple,mm,nid):
	from . import models
	obj=getattr(models,mm)  ##get subtable class,such as memory table
	# ss=obj.objects.all().filter(id=nid)
	temp=obj.objects.get(id=nid)  ##find the item in subtable
	temps=temp.asset_db_set.all() ##with item of subtable reverse find asset_db
	for ll in temps:
		servernn=ll.serverno  ##get asset_db serverno
	item=mm+'s' #module --> asset.items  (such as ethernet-->ethernets)
	asset_xx=asset_db.objects.all().filter(serverno=servernn).values(item) ##find all related item in subtable
	item_list=[]
	for ll in asset_xx:
		item_list.append(ll[item])
	print(item_list)  ##get all relted id list in subtable
	ss=obj.objects.all().filter(id__in=item_list) ##with the related id list to find all objects from subtable
	return render_to_response(temple,{'ss':ss})


@login_required
def asset_db_update(request):
	val=request.session.get('key',None)
	if not val:
		ss=asset_db.objects.all()
	else:
		kwargs={ }
		if val is not None:
			kwargs['serverno__icontains']=val.upper()
			ss=asset_db.objects.filter(**kwargs)

	for line in ss:
		username=line.user
		passwd=line.passwd
		ip=line.ip_addr
		##check server status
		cmdt="ping %s -n 1"% ip
		ret=os.system(cmdt)

		if not ret:
			if line.owner=='linux':  ##for linux os
				try:
					cmd="python /root/client_collect/client.py"
					threads = [6]
					result=[]
					# single thread working
					# ssh = paramiko.SSHClient()
					# ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
					# ssh.connect(ip,22,username,passwd,timeout=5)
					# stdin, stdout, stderr = ssh.exec_command(cmd)
					# result = stdout.read()
					# ssh.close()
					a=threading.Thread(target=ssh2,args=(ip,username,passwd,cmd,result))
					a.start()
					a.join()
					result=result[0]
					# print(result)
					# sys.exit()
					result=eval(result)
					print(result)
					print(type(result))
				except Exception as err:
					print(err)

			else: #for windows os
				# print("windows os")
				try:
					cmd="python C:\client_collect\client.py"  ## for temp use
					# cmd="C:\client_collect\client.exe"          ## for final use
					conn=winrm.Session('http://'+ip+':5985/wsman',auth=(username,passwd))
					r=conn.run_cmd(cmd,)
					# print(r.std_out.decode())
					# print(type(eval(r.std_out.decode())))
					result=eval(r.std_out.decode())
					print(result)
					print(type(result))

					#for local test using
					# from client_collect import client
					# result={}
					# client.collect(result)
					# print(result)
					# print(type(result))
				except Exception as err:
					print(err)

			err_list=[]
			#cpu
			# print(type(result['cpu_info']))
			try:
				try:
					cpu_list=[]
					for cpuu in result['cpu_info']:
						obj=cpu(
						cpu_model=cpuu[0],
						cpu_maker=cpuu[1],
						cpu_frequency=cpuu[2],
						cpu_cores=cpuu[3],
						cpu_threads=cpuu[4],
						cpu_tdp=cpuu[5],  ##for serial number
						cpu_remark=cpuu[6],##for socket
						)
						cpu_list.append(obj)
						obj.save()
					line.cpus=cpu_list
				except Exception as err:
					print(err)
					err_list.append(err)

				#memory
				try:
					mem_list=[]
					for mem in result['mem_info']:
						obj=memory(
						mm_pn=mem[0],
						mm_sn=mem[1],
						mm_frequency=mem[2],
						mm_capacity=mem[3],
						mm_maker=mem[4],
						mm_slot=mem[5],
						)
						mem_list.append(obj)
						obj.save()
					line.memorys=mem_list
				except Exception as err:
					print(err)
					err_list.append(err)


				##network card:
				try:
					e_list=[]
					# 'nic_info': [(' Intel Corporation Ethernet Connection X722 for 10GbE SFP+ (rev 09)', 'Intel', '3.1d 0x800008bb 255.65535.255', '4'), (' Intel Corporation 82599ES 10-Gigabit SFI/SFP+ Network Connection (rev 01)', 'Intel', '0x800006db', '2')],
					for nic in result['nic_info']:
						obj=ethernet(
						e_model=nic[0],
						e_maker=nic[1],
						e_fw=nic[2],
						e_portnum=nic[3],
						e_qty=str(int(nic[3])/4 if int(nic[3])>=4 else 1),
						e_porttype="1GbE/SFP 10GbE" if '722' in nic[0] else nic[4],
						e_slot=nic[6],  #nic[5] for driver
						)
						e_list.append(obj)
						obj.save()
					line.ethernets=e_list
				except Exception as err:
					print(err)
					err_list.append(err)

				##raid card:
				try:
					r_list=[]
					# 'raidcard': ['AVAGO MegaRAID SAS 9361-16i', '4.740.00-8288', 'SK72771059', 'LSI'],
					rr=result['raidcard']
					obj=raid(
						r_model=rr[0],
						r_maker=rr[3],
						r_sn=rr[2],
						r_fw=rr[1],
						r_cache=rr[4],
						r_bbu=rr[5],
						r_remark=rr[7],## for raid slot #nic[6] for driver
						)
					r_list.append(obj)
					obj.save()
					line.raids=r_list
				except Exception as err:
					print(err)
					err_list.append(err)

				##for disk:
				try:
					d_list=[]
					# 'nic_info': [(' Intel Corporation Ethernet Connection X722 for 10GbE SFP+ (rev 09)', 'Intel', '3.1d 0x800008bb 255.65535.255', '4'), (' Intel Corporation 82599ES 10-Gigabit SFI/SFP+ Network Connection (rev 01)', 'Intel', '0x800006db', '2')],
					for dd in result['disk']:
						obj=disk(
						d_model=dd[0],
						d_fw=dd[4],
						d_maker=dd[2],
						d_type=dd[3],
						d_qty=dd[1],
						d_slot=dd[5],
						d_sn=dd[6],
						d_remark=dd[7],
						)
						d_list.append(obj)
						obj.save()
					line.disks=d_list

				except Exception as err:
					print(err)
					err_list.append(err)

				line.status="Online"

				try:
					line.remark3=result['os_type']
				except Exception as err:
					pass
					# err_list.append(err)

				if not err_list:##所有的部分写入都没有错误时，才记录更新时间
					line.remark=datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')

			except Exception as err:
				print(err)

		else:
			line.status="Offline"

		line.save()
	return HttpResponseRedirect('/asset_db_show/')



@login_required
def jumper_main(request):
	ret=request.session.get('serverno',None)
	if ret:
		request.session.pop('serverno')
	ss=asset_db.objects.all()
	return render_to_response("jumpers/jumper_main.html",{'ss':ss})

@login_required
def jumper_file(request):
	file_obj=request.FILES.get('file')
	if file_obj:
		request_set={}
		print("file--obj",file_obj)
		accessory_dir=settings.accessory_dir
		if not os.path.isdir(accessory_dir):
			os.mkdir(accessory_dir)
		upload_file="%s/%s"%(accessory_dir,file_obj.name)
		recv_size=0
		with open(upload_file,'wb') as new_file:
			for chunk in file_obj.chunks():
				new_file.write(chunk)
		print("aaaaa")
		print(upload_file)
		# C:/Users/Administrator/Desktop/python_related_data/zhl_working_directory/server/blog/templates/files/aa.txt

		serverinfo=request.session.get('serverno')
		if serverinfo:
			line=asset_db.objects.all().get(serverno=serverinfo)
			user=line.user
			passwd=line.passwd
			ip=line.ip_addr
			uploadd(ip,user,passwd,upload_file)

		return HttpResponse(json.dumps('上传成功!!'))


@login_required
def jumper_term(request,serverinfo):
	if request.method=='POST':
		# print(request.POST.get('cmd'))
		cmd=request.POST.get('cmd')
		serverinfo=request.session.get('serverno')
		if serverinfo:
			line=asset_db.objects.all().get(serverno=serverinfo)
			user=line.user
			passwd=line.passwd
			ip=line.ip_addr
			# print(user,passwd,ip)
			# print(cmd)

			if line.owner=='linux':
				ss=ssh22(ip,user,passwd,cmd)
			else:
				ss=winrmm(ip,user,passwd,cmd)
			print(ss)
			print(type(ss))
			return HttpResponse(json.dumps(ss))



	line=asset_db.objects.all().get(serverno=serverinfo)
	user=line.user
	passwd=line.passwd
	ip=line.ip_addr
	print(user,passwd,ip)
	request.session['serverno']=serverinfo
	ss=' '
	# cmd="C:/Python27/python27.exe C:/Users/Administrator/Desktop/python_related_data/zhl_working_directory/cmdb/sansa/ssh_client.py "+ip+" "+user+" "+passwd+" lsblk"
	# ret=os.popen(cmd)
	# ss=ret.read()
	# print(ss)
	return render_to_response("jumpers/jumper_term.html",{'ss':ss})








@login_required
def asset(request): #without it , admin page is error,need checking
	# print "111111"
	ss=Server_db.objects.all()
        cmd = ["cat /proc/cpuinfo  | grep model | grep Intel | uniq -c|cut -d: -f2","dmidecode -t memory|grep -i part|sed -n '1,24p'| grep -v Unknown |grep -v NO| uniq -c|awk '{print $1,$4}'","lspci | grep -i eth","storcli /c0 show all | grep -E 'HDD|SSD' | grep ^[0-9]|awk '{print $(NF-1)}' |uniq -c && sas3ircu 0 display | grep -i model | awk '{print $NF}'|uniq -c","storcli show | grep '^ \{0,2\}[0-9]'|awk '{print $2}'&&sas3ircu 0 display | grep -i 'controller type'|awk '{print $NF}'","sg_logs -a /dev/nvme0n1 | grep -i nvme | awk '{print $2}' && sg_logs -a /dev/nvme1n1 | grep -i nvme | awk '{print $2}'"]
        for line in ss:
		result=[]
		username=line.user

        	passwd =line.passwd
        	threads = [10]
		ip=line.ip_addr

		##check server status
		cmdt="ping %s -c 1"% ip
		ret=os.system(cmdt)

		if not ret:
        		a=threading.Thread(target=ssh2,args=(ip,username,passwd,cmd,result))
        		a.start()
        		time.sleep(7)
			#print result

			##for cpu processing
			cpu=result[0]
			p=re.compile(r'\s(E\d+-\d+\sv\d)\s')
			tt=p.findall(cpu)
			#print tt
			tt="".join(tt)
			if not tt.strip():
				p=re.compile(r'\s(\w+\s\d+\w+)\s')
				tt=p.findall(cpu)
				tt="".join(tt)+"*2"

			line.cpu=tt

			##for memory processing
			memory=result[1]
			#print result[1]
			tt=re.sub(r'\s+','*',memory)
			#print tt
			line.memory=tt

			##for network card processing
			card=result[2]
			#p=re.compile(r'\s(\D{0,1}\d+)\s')
			#p=re.compile(r'\s(I?\d+[A-Z]{0,4})\s')
			## modify @2017.11.16 for x722,82599
			p=re.compile(r'\s(\w\d\d\w+)\s')
			tt=p.findall(card)
			t=list(tt)
			tt="/".join(t)
			#print tt
			if not tt.strip():
				p=re.compile(r'\s(\d+\w+\d+)\s')
				tt=p.findall(card)
				t=list(tt)
				tt="/".join(t)

			if not tt.strip():
				p=re.compile(r'\s(\w?\d+)\s')
				tt=p.findall(card)
				t=list(tt)
				tt="/".join(t)

			line.ethernet=tt

			##for disk processing
			tt=result[3]
			p=re.compile(r'\S+')
			t=p.findall(tt)
			tt="/".join(t)
			#print tt
			line.disk=tt

			##for raid card processing
			line.raid=result[4]
			#print result[4]

			##for nvme processing
			tt=result[5]
			if len(tt) > 20:
				line.nvme=tt[0:15]+"*2"
			else:
				line.nvme=tt

			##server status
			line.status="Online"

			## write data to server_db database
			#dic={'name':line.name,'ip_addr':line.ip_addr,'cpu':result[0],'memory':result[1],'ethernet':result[2],'disk':result[3],'raid':result[4]}
			line.save()
		else:
			line.status="Offline"
			line.save()
			#continue
	ss=Server_db.objects.all()
	return render_to_response('asset.html',{'ss':ss,'k1':"testing"})  #   ##w  #

