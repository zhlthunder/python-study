from django.contrib import admin
from blog.models import *
from django.contrib.auth.admin import UserAdmin  


class Server_dbAdmin(admin.ModelAdmin):
	search_fields=('name',)
	list_display=('name','ip_addr','cpu_s','memory_s','ethernet_s','disk_s','raid_s','nvme_s')


class cmcc_material_trackingAdmin(admin.ModelAdmin):
	search_fields=('serial','model','type__typename','wherefrom','location','status','desc1')
	list_display=('model','serial','type','qty','wherefrom','location','status','desc1',)


class cmcc_internal_borrowAdmin(admin.ModelAdmin):
	search_fields=('model','Borrower',)
	list_display=('date','model','serial','Borrower','qty','return_date','status')

class Disk_infoAdmin(admin.ModelAdmin):
	search_fields=('d_model',)
	list_display=('d_model','bw_r_spec','bw_w_spec','iops_r_spec','iops_w_spec','disk_cache','d_vendor','d_health')
	#list_filter=('d_vendor')
	#date_hierarchy='publication_date'
	#ordering=('publication_date',)

class Disk_resourceAdmin(admin.ModelAdmin):
	search_fields=('Model',)
	list_display=('Model','inch','Qty','BOX_NO','Interface','Capacity')

class Disk_borrowAdmin(admin.ModelAdmin):
	search_fields=('Borrower',)
	list_display=('Model','Borrow_date','Borrower','QTY','Return_date')

class Nvme_ssd_dbAdmin(admin.ModelAdmin):
	search_fields=('n_model',)
	list_display=('n_model','seq_r_bw_spec','seq_w_bw_spec','rand_r_iops_4k_spec','rand_w_iops_4k_spec','rand_r_iops_8k_spec','rand_w_iops_8k_spec','rand_rw_iops_4k_spec','rand_rw_iops_8k_spec','seq_r_lat_4k_spec','seq_w_lat_4k_spec','rand_r_lat_4k_spec','rand_w_lat_4k_spec')


class asset_dbAdmin(admin.ModelAdmin):
	search_fields=('serverno',)
	list_display=('serverno','ip_addr','user','passwd','owner')
	# def ethernets_id(self,obj):
	# 	# print(obj.ethernets.ethernets_id)
	# 	return obj.ethernets.ethernets_id

class memoryAdmin(admin.ModelAdmin):
	list_display =('mm_pn','mm_sn','mm_frequency','mm_capacity')

class cpuAdmin(admin.ModelAdmin):
	list_display =('cpu_model','cpu_maker','cpu_frequency','cpu_tdp')

class ethernetAdmin(admin.ModelAdmin):
	list_display =('e_model','e_sn','e_fw','e_maker')

class fccardAdmin(admin.ModelAdmin):
	list_display =('f_model','f_sn','f_fw','f_maker')

class diskAdmin(admin.ModelAdmin):
	list_display =('d_model','d_fw','d_maker')

class raidAdmin(admin.ModelAdmin):
	list_display =('r_model','r_fw','r_maker')

class nvmeAdmin(admin.ModelAdmin):
	list_display =('n_model','n_fw','n_maker')

#admin.site.register(Publisher)
#admin.site.register(Author)
#admin.site.register(Book,BookAdmin)
admin.site.register(Server_db,Server_dbAdmin)
admin.site.register(Nvme_ssd_db,Nvme_ssd_dbAdmin)
admin.site.register(Disk_info,Disk_infoAdmin)
admin.site.register(Disk_resource,Disk_resourceAdmin)
admin.site.register(Disk_borrow,Disk_borrowAdmin)
admin.site.register(cmcc_material_tracking,cmcc_material_trackingAdmin)
admin.site.register(material_type)
admin.site.register(cmcc_internal_borrow,cmcc_internal_borrowAdmin)


admin.site.register(asset_db,asset_dbAdmin)
admin.site.register(ethernet,ethernetAdmin)
admin.site.register(fccard,fccardAdmin)
admin.site.register(disk,diskAdmin)
admin.site.register(raid,raidAdmin)
admin.site.register(nvme,nvmeAdmin)
admin.site.register(memory,memoryAdmin)
admin.site.register(cpu,cpuAdmin)
