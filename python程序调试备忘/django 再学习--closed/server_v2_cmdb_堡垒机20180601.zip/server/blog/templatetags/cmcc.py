#!/usr/bin/env python
# -*- coding: utf-8 -*-


from django import template

register = template.Library()  

##实现分类汇总 fro 内存
@register.filter
def funcc(obj):
    res={}
    for i in obj:
        res[i.mm_pn]=res.get(i.mm_pn,0)+1
    la=[k for k in res.keys()]
    lb=[k for k in res.values()]
    temp=zip(la,lb)
    # result=''
    # for ii in temp:
    #     result+=str(ii[0])+'*'+str(ii[1])
    # return result
    return temp

##实现分类汇总 fro 硬盘
@register.filter
def funccc(obj):
    res={}
    for i in obj:
        res[i.d_model]=res.get(i.d_model,0)+1
    la=[k for k in res.keys()]
    lb=[k for k in res.values()]
    temp=zip(la,lb)
    # result=''
    # for ii in temp:
    #     result+=str(ii[0])+'*'+str(ii[1])+'\r'
    # return result
    return temp


##实现分类汇总 fro cpu
@register.filter
def funcccc(obj):
    res={}
    for i in obj:
        res[i.cpu_model]=res.get(i.cpu_model,0)+1
    la=[k for k in res.keys()]
    lb=[k for k in res.values()]
    temp=zip(la,lb)
    result=''
    for ii in temp:
        result+=str(ii[0])+'*'+str(ii[1])+'\r'
    return result


@register.filter
def f1(value):
    return "testing" + "666"


@register.filter
def f2(value, arg):
    return value + "666" + arg


@register.simple_tag
def f3(value, s1, s2, s3, s4):
    return value + "666" + s1 + s2 + s3 + s4



@register.simple_tag
def fspec(spec):
    if spec in  'Online':
        return "color:green"
    else:
        return "color:red"

@register.simple_tag
def diss(val):
    if val!=1:
        return "display:None"

@register.simple_tag
def dissa(val):
    if val==1:
        return " "
