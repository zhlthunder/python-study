#!/usr/bin/env python
# -*- coding: utf-8 -*-


def table_process():
    from sansa import create_app
    from sansa import db
    from sansa import models
    import  json

    app = create_app()

    with app.app_context(): #必须加载当前app的上下文，即把flask app相关的所有信息都加载到Local（）中

         ##cpu
        cc=db.session.query(models.Cpu).all()
        for line in cc:
            obj=line.asset_dbs.all()
            if not obj:
                db.session.delete(line)
        db.session.commit()

         ##memory
        cc=db.session.query(models.Memory).all()
        for line in cc:
            obj=line.asset_dbs.all()
            if not obj:
                db.session.delete(line)
        db.session.commit()

        ##raid
        cc=db.session.query(models.Raid).all()
        for line in cc:
            obj=line.asset_dbs.all()
            if not obj:
                db.session.delete(line)
        db.session.commit()

        ##disk
        cc=db.session.query(models.Disk).all()
        for line in cc:
            obj=line.asset_dbs.all()
            if not obj:
                db.session.delete(line)
        db.session.commit()


        ##fccard
        cc=db.session.query(models.Fccard).all()
        for line in cc:
            obj=line.asset_dbs.all()
            if not obj:
                db.session.delete(line)
        db.session.commit()


        ##ethernet
        cc=db.session.query(models.Ethernet).all()
        for line in cc:
            obj=line.asset_dbs.all()
            if not obj:
                db.session.delete(line)
        db.session.commit()


        ##NVME
        cc=db.session.query(models.Nvme).all()
        for line in cc:
            obj=line.asset_dbs.all()
            if not obj:
                db.session.delete(line)
        db.session.commit()

if __name__ == '__main__':
    table_process()

