#!/usr/bin/env python
# -*- coding: utf-8 -*-
#author:zhl

##离线脚本，用于创建表或删除表


from sansa import create_app
from sansa import db
from sansa import models
import  json

app = create_app()

with app.app_context(): #必须加载当前app的上下文，即把flask app相关的所有信息都加载到Local（）中
    pass
    db.create_all()  ##创建表
    # db.drop_all()   #删除表

    ##查询
    #单表查询
    # data=db.session.query(models.Asset_db).all()
    # print(data)

    # data=db.session.query(models.Cpu).all()
    # print(data)

    ##关联查询
    ##通过单条纪录查询关联表的信息,使用first()后得到的类型为：<class 'sansa.models.Asset_db'>，可以使用cpus字段查询管理表
    # asset1=db.session.query(models.Asset_db).filter(models.Asset_db.id == 4).first()
    # print(type(asset1))
    # print(type(asset1))
    # print(type(asset1.cpus.first().cpu_model))

    ##正向：多条记录查询关联表的信息； 说明： all()获取的对象类型为 <class 'list'>， 不可以使用cpus字段查询关联表，需要循环没有元素了再使用。
    # asset1=db.session.query(models.Asset_db).filter(models.Asset_db.serverno.ilike('%00%') ).all()
    # print(type(asset1))
    # for ii in asset1:
    #     print(ii.cpus.all())

    #反向：多条记录查询关联表的信息
    # cpu1=db.session.query(models.Cpu).filter(models.Cpu.cpu_model.ilike('%1%')).all()
    # # print(cpu1)
    # for ii in cpu1:
    #     print(ii.asset_dbs.all())



   ##添加纪录
    #单表增加纪录方法1：
    # db.session.add(models.Asset_db(serverno='r4300',ip_addr='128.1.2.1',user='root',passwd='123',os='linux'))
    # db.session.commit()

    #单表增加纪录方法2:
    # asset1=models.Asset_db(serverno='r5300',ip_addr='128.1.7.1',user='root',passwd='123',os='linux')
    # db.session.add(asset1)
    # db.session.commit()

    # cpu1=models.Cpu(cpu_model='5118',cpu_maker='intel',cpu_frequency='2000hz',cpu_tdp='500w',cpu_cores='8',cpu_threads='20')
    # db.session.add(cpu1)
    # db.session.commit()

    ##多对多涉及的3张表同时增加纪录的方法：
    # asset2=models.Asset_db(serverno='r5500',ip_addr='129.1.7.1',user='root',passwd='123',os='linux')
    # asset2.cpus=[models.Cpu(cpu_model='8118',cpu_maker='intel',cpu_frequency='3000hz',cpu_tdp='600w',cpu_cores='8',cpu_threads='20'),
    #              models.Cpu(cpu_model='4118',cpu_maker='intel',cpu_frequency='1000hz',cpu_tdp='600w',cpu_cores='8',cpu_threads='20'),
    #              ]
    # db.session.add(asset2)
    # db.session.commit()

   ##多对多关系，同时增加多条记录
    # asset3=models.Asset_db(serverno='r5700',ip_addr='123.1.7.1',user='root',passwd='123',os='windows')
    # asset3.cpus=[models.Cpu(cpu_model='7117',cpu_maker='intel',cpu_frequency='1000hz',cpu_tdp='600w',cpu_cores='8',cpu_threads='20'),]
    # asset3.memorys=[models.Memory(mm_pn='PNA12W',mm_sn='123334')]
    # asset3.ethernets=[models.Ethernet(e_model='x722',e_sn='123334')]
    # asset3.fccards=[models.Fccard(f_model='LPE12002',f_sn='123334')]
    # asset3.disks=[models.Disk(d_model='AL13SEB600',d_fw='123334')]
    # asset3.raids=[models.Raid(r_model='9361-8I',r_fw='123334')]
    # asset3.nvmes=[models.Nvme(n_model='P877234',n_fw='123334')]
    # db.session.add(asset3)
    # db.session.commit()


    ##删除：
    # db.session.query(models.Cpu).filter(models.Cpu.id==1).delete()
    # db.session.commit()

    ##改：
    ##直接修改某个字段
    # db.session.query(models.Cpu).filter(models.Cpu.id==2).update({'cpu_model':'9118'})
    # db.session.commit()

    # db.session.query(models.Cpu).filter(models.Cpu.id==2).update({models.Cpu.cpu_model:models.Cpu.cpu_model+'_00'},synchronize_session=False)
    # db.session.commit()

    ##单表更新：
    # ss=db.session.query(models.Asset_db).filter(models.Asset_db.serverno=='r8500').first()
    # print(ss.serverno)
    # ss.serverno='r85800'
    # db.session.flush()
    # db.session.commit()

    ##多对多关系下的更新方法
    # ss=db.session.query(models.Asset_db).filter(models.Asset_db.serverno=='r85800').first()
    # # print(ss)
    # ss.cpus=[models.Cpu(cpu_model='77118',cpu_maker='intel',cpu_frequency='3000hz',cpu_tdp='600w',cpu_cores='8',cpu_threads='20'),
    #          models.Cpu(cpu_model='44118',cpu_maker='intel',cpu_frequency='1000hz',cpu_tdp='600w',cpu_cores='8',cpu_threads='20'),
    #          ]
    # db.session.flush()
    # db.session.commit()



   ##双重查找确认
    # ss=db.session.query(models.Cpu).filter(models.Cpu.cpu_model=='5118 CPU ').first()
    # print(ss.asset_dbs.first().cpus.all())
    # aa=ss.asset_dbs.first().cpus.all()
    # for ll in aa:
    #     print(ll.cpu_maker)

    ##关联表的删除操作：
    #cpu:
    # uu=db.session.query(models.Asset_db).filter(models.Asset_db.serverno=='r5300g4-1').first().cpus.all()
    # for ii in uu:
    #     db.session.query(models.Asset_db).filter(models.Asset_db.serverno=='r5300g4-1').first().cpus.remove(ii)
    #     db.session.commit()

    # uu=db.session.query(models.Asset_db).filter(models.Asset_db.serverno=='r5300g4-1').first().disks.all()
    # for ii in uu:
    #     db.session.query(models.Asset_db).filter(models.Asset_db.serverno=='r5300g4-1').first().disks.remove(ii)
    # db.session.commit()

