#!/usr/bin/env python
# -*- coding:utf-8 -*-
"""
生成依赖文件：
    pipreqs ./

"""
from sansa import create_app

app = create_app()  ##使用flask的推荐用法
from sansa.templatetag.mytag import *   ##导入自定义标签，因为其中使用了app,需要在创建app后执行导入
from sansa.middleware.mymd import * ##导入自定义中间件函数，因为其中使用了app,需要在创建app后执行导入


if __name__ == '__main__':
    app.run(debug=True,host='128.1.2.250')

