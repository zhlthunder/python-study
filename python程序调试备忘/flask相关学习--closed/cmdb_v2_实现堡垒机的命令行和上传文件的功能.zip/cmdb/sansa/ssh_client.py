#!/usr/bin/env python
# -*- coding: utf-8 -*-

import paramiko,sys

# print("111111")

def ssh2(ip,username,passwd,cmd):
    try:
        # print(cmd)
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(ip,22,username,passwd,timeout=5)
        stdin, stdout, stderr = ssh.exec_command(cmd)
        ret=stdout.read()
        # print('%s\tOK\n'%(ip))
        print(ret)
        ssh.close()

    except :
        # print '%s\tError\n'%(ip)
        pass

# if __name__ == '__main__':
# ip='128.1.2.201'
# user='root'
# passwd='123456'
# cmd='lsblk'
# li=[]
# ssh2(ip,user,passwd,cmd,li)
temp=sys.argv[4:]
temp=" ".join(temp)
ssh2(sys.argv[1],sys.argv[2],sys.argv[3],temp)
# print(sys.argv)