#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os

# cmd="C:/Python27/python27.exe C:/Users/Administrator/Desktop/python_related_data/zhl_working_directory/cmdb/sansa/ssh_client.py"
# cmd="C:/Python27/python27.exe ssh_client.py  128.1.2.201 root 123456 lspci|grep -i eth"
cmd="C:/Python27/python27.exe C:/Users/Administrator/Desktop/python_related_data/zhl_working_directory/cmdb/sansa/sftp_client.py"
ret=os.popen(cmd)
print(ret.read())