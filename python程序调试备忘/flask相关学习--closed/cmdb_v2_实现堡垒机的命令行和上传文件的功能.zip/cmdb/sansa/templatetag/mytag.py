#!/usr/bin/env python
# -*- coding: utf-8 -*-

from run import app



# self-define filter-tag:接收一个参数，即为被过滤的对象，前端通过管道符来赋值：{{ line.cpus.all()|funcccc }}
def funcccc(obj):
    res={}
    for i in obj:
        res[i.cpu_model]=res.get(i.cpu_model,0)+1
    la=[k for k in res.keys()]
    lb=[k for k in res.values()]
    temp=zip(la,lb)
    result=''
    for ii in temp:
        result+=str(ii[0])+'*'+str(ii[1])+'\r'
    return result




##实现分类汇总 fro 内存
def funcc(obj):
    res={}
    for i in obj:
        res[i.mm_pn]=res.get(i.mm_pn,0)+1
    la=[k for k in res.keys()]
    lb=[k for k in res.values()]
    temp=zip(la,lb)
    return temp

##实现分类汇总 fro 硬盘
def funccc(obj):
    res={}
    for i in obj:
        res[i.d_model]=res.get(i.d_model,0)+1
    la=[k for k in res.keys()]
    lb=[k for k in res.values()]
    temp=zip(la,lb)
    return temp


env=app.jinja_env
env.filters['funcccc']=funcccc  ##注册自定义过滤器
env.filters['funcc']=funcc  ##注册自定义过滤器
env.filters['funccc']=funccc ##注册自定义过滤器


def interval(test_str,start,end): #第一个参数为被过滤对象，第二三参数需求自己传入， 调用方法：{{test_str| interval(0,2)}}
    return test_str[int(start):int(end)]
env.filters['interval']=interval #注册自定义过滤器

