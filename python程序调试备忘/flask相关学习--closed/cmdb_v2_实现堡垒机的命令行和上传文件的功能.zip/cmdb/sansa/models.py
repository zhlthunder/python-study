#!/usr/bin/env python
# -*- coding: utf-8 -*-

from . import db


# class Users(db.Model):  # self.Model = self.make_declarative_base(model_class, metadata)  相当于之前用的Base
#     """
#     用户表
#     """
#     __tablename__ = 'users'
#     id = db.Column(db.Integer, primary_key=True)
#     username = db.Column(db.String(80), unique=True, nullable=True)
#     email = db.Column(db.String(120), unique=True, nullable=True)
#
#     def __repr__(self):
#         return '<User %r>' % self.username


##for cmdb models
#
class asset_db2_cpu(db.Model):
    __tablename__ = 'asset_db2cpu'
    id = db.Column(db.Integer, primary_key=True,autoincrement=True)
    asset_db_id=db.Column(db.Integer,db.ForeignKey('asset_db.id'))
    cpu_id=db.Column(db.Integer,db.ForeignKey('cpu.id'))

class asset_db2_memory(db.Model):
    __tablename__ = 'asset_db2memory'
    id = db.Column(db.Integer, primary_key=True,autoincrement=True)
    asset_db_id=db.Column(db.Integer,db.ForeignKey('asset_db.id'))
    memory_id=db.Column(db.Integer,db.ForeignKey('memory.id'))

class asset_db2_ethernet(db.Model):
    __tablename__ = 'asset_db2ethernet'
    id = db.Column(db.Integer, primary_key=True,autoincrement=True)
    asset_db_id=db.Column(db.Integer,db.ForeignKey('asset_db.id'))
    ethernet_id=db.Column(db.Integer,db.ForeignKey('ethernet.id'))

class asset_db2_fccard(db.Model):
    __tablename__ = 'asset_db2fccard'
    id = db.Column(db.Integer, primary_key=True,autoincrement=True)
    asset_db_id=db.Column(db.Integer,db.ForeignKey('asset_db.id'))
    fccard_id=db.Column(db.Integer,db.ForeignKey('fccard.id'))

class asset_db2_disk(db.Model):
    __tablename__ = 'asset_db2disk'
    id = db.Column(db.Integer, primary_key=True,autoincrement=True)
    asset_db_id=db.Column(db.Integer,db.ForeignKey('asset_db.id'))
    disk_id=db.Column(db.Integer,db.ForeignKey('disk.id'))

class asset_db2_raid(db.Model):
    __tablename__ = 'asset_db2raid'
    id = db.Column(db.Integer, primary_key=True,autoincrement=True)
    asset_db_id=db.Column(db.Integer,db.ForeignKey('asset_db.id'))
    raid_id=db.Column(db.Integer,db.ForeignKey('raid.id'))

class asset_db2_nvme(db.Model):
    __tablename__ = 'asset_db2nvme'
    id = db.Column(db.Integer, primary_key=True,autoincrement=True)
    asset_db_id=db.Column(db.Integer,db.ForeignKey('asset_db.id'))
    nvme_id=db.Column(db.Integer,db.ForeignKey('nvme.id'))



class Cpu(db.Model):
    __tablename__ = 'cpu'
    id = db.Column(db.Integer, primary_key=True,autoincrement=True)
    cpu_model=db.Column(db.String(100), nullable=True)
    cpu_maker=db.Column(db.String(100), nullable=True)
    cpu_frequency=db.Column(db.String(100), nullable=True)
    cpu_tdp=db.Column(db.String(100), nullable=True)
    cpu_cores=db.Column(db.String(100), nullable=True)
    cpu_threads=db.Column(db.String(100), nullable=True)
    cpu_remark=db.Column(db.String(100), nullable=True)

    def __repr__(self):
        return '<cpu %r>' % self.cpu_model


class Memory(db.Model):
    __tablename__ = 'memory'
    id = db.Column(db.Integer, primary_key=True,autoincrement=True)
    mm_pn=db.Column(db.String(100), nullable=True)
    mm_sn=db.Column(db.String(100), nullable=True)
    mm_frequency=db.Column(db.String(100), nullable=True)
    mm_capacity=db.Column(db.String(100), nullable=True)
    mm_maker=db.Column(db.String(100), nullable=True)
    mm_slot=db.Column(db.String(100), nullable=True)
    mm_remark=db.Column(db.String(100), nullable=True)
    mm_remark2=db.Column(db.String(100), nullable=True)

    def __repr__(self):
        return '<Memory %r>' % self.mm_pn


class Ethernet(db.Model):
    __tablename__ = 'ethernet'
    id = db.Column(db.Integer, primary_key=True,autoincrement=True)
    e_model=db.Column(db.String(100), nullable=True)
    e_sn=db.Column(db.String(100), nullable=True)
    e_fw=db.Column(db.String(100), nullable=True)
    e_maker=db.Column(db.String(100), nullable=True)
    e_portnum=db.Column(db.String(100), nullable=True)
    e_porttype=db.Column(db.String(100), nullable=True)
    e_qty=db.Column(db.String(100), nullable=True)
    e_slot=db.Column(db.String(100), nullable=True)
    e_remark=db.Column(db.String(100), nullable=True)
    e_remark2=db.Column(db.String(100), nullable=True)


    def __repr__(self):
        return '<Ethernet %r>' % self.e_model

class Fccard(db.Model):
    __tablename__ = 'fccard'
    id = db.Column(db.Integer, primary_key=True,autoincrement=True)
    f_model=db.Column(db.String(100), nullable=True)
    f_sn=db.Column(db.String(100), nullable=True)
    f_fw=db.Column(db.String(100), nullable=True)
    f_maker=db.Column(db.String(100), nullable=True)
    f_portnum=db.Column(db.String(100), nullable=True)
    f_qty=db.Column(db.String(100), nullable=True)
    f_remark=db.Column(db.String(100), nullable=True)


    def __repr__(self):
        return '<Fccard %r>' % self.f_model


class Disk(db.Model):
    __tablename__ = 'disk'
    id = db.Column(db.Integer, primary_key=True,autoincrement=True)
    d_model=db.Column(db.String(100), nullable=True)
    d_fw=db.Column(db.String(100), nullable=True)
    d_maker=db.Column(db.String(100), nullable=True)
    d_type=db.Column(db.String(100), nullable=True)
    d_qty=db.Column(db.String(100), nullable=True)
    d_slot=db.Column(db.String(100), nullable=True)
    d_sn=db.Column(db.String(100), nullable=True)
    d_remark=db.Column(db.String(100), nullable=True)
    d_remark2=db.Column(db.String(100), nullable=True)

    def __repr__(self):
        return '<Disk %r>' % self.d_model


class Raid(db.Model):
    __tablename__ = 'raid'
    id = db.Column(db.Integer, primary_key=True,autoincrement=True)
    r_model=db.Column(db.String(100), nullable=True)
    r_sn=db.Column(db.String(100), nullable=True)
    r_fw=db.Column(db.String(100), nullable=True)
    r_maker=db.Column(db.String(100), nullable=True)
    r_cache=db.Column(db.String(100), nullable=True)
    r_bbu=db.Column(db.String(100), nullable=True)
    r_remark=db.Column(db.String(100), nullable=True)
    r_remark2=db.Column(db.String(100), nullable=True)

    def __repr__(self):
        return '<Raid %r>' % self.r_model


class Nvme(db.Model):
    __tablename__ = 'nvme'
    id = db.Column(db.Integer, primary_key=True,autoincrement=True)
    n_model=db.Column(db.String(100), nullable=True)
    n_sn=db.Column(db.String(100), nullable=True)
    n_fw=db.Column(db.String(100), nullable=True)
    n_maker=db.Column(db.String(100), nullable=True)
    n_qty=db.Column(db.String(100), nullable=True)
    n_remark=db.Column(db.String(100), nullable=True)

    def __repr__(self):
        return '<Nvme %r>' % self.n_model


class Asset_db(db.Model):
    __tablename__ = 'asset_db'
    id = db.Column(db.Integer, primary_key=True,autoincrement=True)
    serverno=db.Column(db.String(100), nullable=True)
    ip_addr=db.Column(db.String(100), nullable=True)
    user=db.Column(db.String(100), nullable=True)
    passwd=db.Column(db.String(100), nullable=True)
    os=db.Column(db.String(100), nullable=True)
    status=db.Column(db.String(100), nullable=True)
    remark=db.Column(db.String(100), nullable=True)
    remark2=db.Column(db.String(100), nullable=True)
    remark3=db.Column(db.String(100), nullable=True)


    cpus=db.relationship('Cpu',secondary='asset_db2cpu',backref=db.backref('asset_dbs',lazy='dynamic'),lazy='dynamic')
    memorys=db.relationship('Memory',secondary='asset_db2memory',backref=db.backref('asset_dbs',lazy='dynamic'),lazy='dynamic')
    ethernets=db.relationship('Ethernet',secondary='asset_db2ethernet',backref=db.backref('asset_dbs',lazy='dynamic'),lazy='dynamic')
    fccards=db.relationship('Fccard',secondary='asset_db2fccard',backref=db.backref('asset_dbs',lazy='dynamic'),lazy='dynamic')
    disks=db.relationship('Disk',secondary='asset_db2disk',backref=db.backref('asset_dbs',lazy='dynamic'),lazy='dynamic')
    raids=db.relationship('Raid',secondary='asset_db2raid',backref=db.backref('asset_dbs',lazy='dynamic'),lazy='dynamic')
    nvmes=db.relationship('Nvme',secondary='asset_db2nvme',backref=db.backref('asset_dbs',lazy='dynamic'),lazy='dynamic')



    def __repr__(self):
        return '<Asset_db %r>' % self.serverno





