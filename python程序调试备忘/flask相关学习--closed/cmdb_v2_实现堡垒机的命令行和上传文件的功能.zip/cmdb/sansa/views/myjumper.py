#!/usr/bin/env python
# -*- coding: utf-8 -*-

from flask import Blueprint,render_template,request,session,jsonify
from .. import db
from .. import models
import os,sys




myjumper=Blueprint("myjumper",__name__)

@myjumper.route("/jumper/",methods=['GET','POST'])
def jumper_main():
    ret=session.get('serverno',None)
    if ret:
        session.pop('serverno')
    ss=db.session.query(models.Asset_db).all()
    return render_template("jumpers/jumper_main.html",ss=ss)

@myjumper.route('/jumper_file/',methods=['GET','POST'])
def jumper_file():
    if request.method=="POST":
        file=request.files['file']
        file_name=file.filename
        filenew=os.path.join('sansa\\templates\\files',file_name).replace("\\",'/')
        file.save(filenew)
        print(filenew)
        serverinfo=session.get('serverno')
        if serverinfo:
            line=db.session.query(models.Asset_db).filter(models.Asset_db.serverno==serverinfo).first()
            user=line.user
            passwd=line.passwd
            ip=line.ip_addr
            cmdd="C:/Python27/python27.exe C:/Users/Administrator/Desktop/python_related_data/zhl_working_directory/cmdb/sansa/sftp_client.py "+ip+" "+user+" "+passwd+" "+filenew
            ret=os.popen(cmdd)
            ss=ret.read()


        return "上传成功！"

@myjumper.route('/jumper_term/<serverinfo>/',methods=['GET','POST'])
def jumper_term(serverinfo):
    if request.method=='POST':
        print(request.form.get('cmd'))
        cmd=request.form.get('cmd')
        serverinfo=session.get('serverno')
        if serverinfo:
            line=db.session.query(models.Asset_db).filter(models.Asset_db.serverno==serverinfo).first()
            user=line.user
            passwd=line.passwd
            ip=line.ip_addr
            # print(user,passwd,ip)
            print(cmd)

            cmdd="C:/Python27/python27.exe C:/Users/Administrator/Desktop/python_related_data/zhl_working_directory/cmdb/sansa/ssh_client.py "+ip+" "+user+" "+passwd+" "+cmd
            ret=os.popen(cmdd)
            ss=ret.read()
            # print(ss)
            # data={
            #     'response':ss
            # }
            # return "ok"
            return jsonify(ss)



    line=db.session.query(models.Asset_db).filter(models.Asset_db.serverno==serverinfo).first()
    user=line.user
    passwd=line.passwd
    ip=line.ip_addr
    print(user,passwd,ip)
    session['serverno']=serverinfo
    ss=' '
    # cmd="C:/Python27/python27.exe C:/Users/Administrator/Desktop/python_related_data/zhl_working_directory/cmdb/sansa/ssh_client.py "+ip+" "+user+" "+passwd+" lsblk"
    # ret=os.popen(cmd)
    # ss=ret.read()
    # print(ss)
    return render_template("jumpers/jumper_term.html",ss=ss)