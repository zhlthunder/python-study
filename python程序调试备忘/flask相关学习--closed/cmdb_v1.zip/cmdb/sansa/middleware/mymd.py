#!/usr/bin/env python
# -*- coding: utf-8 -*-

from run import app
from table_process_offline import table_process

@app.before_request
def preprocess():
    # print("来了")
    table_process()
