#!/usr/bin/env python
# -*- coding:utf-8 -*-
#encoding=utf-8

from flask import Blueprint,redirect,render_template,request,session,jsonify,g,current_app
from .. import db
from .. import models
import re
import os,sys,threading
from .. import p_ssh_expect_multi
import threading
import copy,datetime

lock=threading.Lock()


account = Blueprint('account', __name__)


@account.route('/',methods=['GET','POST'])
def index():
	# return render_template('index.html')
	return redirect('/asset_db_show/')


@account.route('/asset_db_show/',methods=['GET','POST'])
# @account.route('/',methods=['GET','POST'])
def asset_db_show():
	tt=session.get('key')
	if not tt:
		ss=db.session.query(models.Asset_db).all()
	else:
		ss=db.session.query(models.Asset_db).filter(models.Asset_db.serverno.ilike('%'+tt+'%')).all()
		session.pop('key')
	return render_template('cmdb/asset_db.html',ss=ss)


@account.route('/asset_search/',methods=['GET','POST'])
def asset_search():
	tt=request.form.get('ServerNo')
	# print(tt)
	session['key']=tt
	ss=db.session.query(models.Asset_db).filter(models.Asset_db.serverno.ilike('%'+tt+'%')).all()
	return render_template('cmdb/asset_db.html',ss=ss)

@account.route('/<module>/detail/<int:pid>/')
def asset_db_detail(module,pid):
	obj=getattr(models,module.capitalize())  ##获取子表模块
	# print(obj)
	# ss=db.session.query(obj).filter(obj.id==pid).all()

	ss=db.session.query(obj).filter(obj.id==pid).first()

	if module=='cpu':
		aa=ss.asset_dbs.first().cpus.all()
	elif module=='memory':
		aa=ss.asset_dbs.first().memorys.all()
	elif module=='nvme':
		aa=ss.asset_dbs.first().nvmes.all()
	elif module=='disk':
		aa=ss.asset_dbs.first().disks.all()
	elif module=='ethernet':
		aa=ss.asset_dbs.first().ethernets.all()
	elif module=='fccard':
		aa=ss.asset_dbs.first().fccards.all()
	elif module=='raid':
		aa=ss.asset_dbs.first().raids.all()

	temp="cmdb/"+module+".html"
	# print(temp)
	return render_template(temp,ss=aa)



@account.route('/submit_asset/',methods=['GET','POST'])
def submit_asset():
	if request.method=='POST':
		ip=request.form.get('ip')
		serverno=request.form.get('serverno')
		user=request.form.get('user')
		passwd=request.form.get('passwd')
		owner=request.form.get('owner')
		# print(ip,user,passwd)
		##insert into db base
		db.session.add(models.Asset_db(serverno=serverno,ip_addr=ip,user=user,passwd=passwd,status='Online',os=owner))
		db.session.commit()
		return redirect('/asset_db_show/')

	return render_template('cmdb/submit_asset.html')


##for update basic server info(username, password,ip,and so on)
@account.route('/sub/<servernumber>',methods=['GET','POST'])
def sub_server(servernumber):
	if request.method=='POST':
		ip=request.form.get('ip')
		servernoo=request.form.get('serverno')
		user=request.form.get('user')
		passwd=request.form.get('passwd')
		owner=request.form.get('owner')
		# print(ip,user,passwd)
		##insert into db base
		new_data={'serverno':servernoo,'ip_addr':ip,'user':user,'passwd':passwd,'os':owner}
		servernumber=session.get('server')
		print(servernumber)
		db.session.query(models.Asset_db).filter(models.Asset_db.serverno==servernumber).update(new_data)
		db.session.commit()
		return redirect('/asset_db_show/')
	else:
		ss=db.session.query(models.Asset_db).filter(models.Asset_db.serverno==servernumber).first()
		session['server']=servernumber
		return render_template("cmdb/submit_asset.html",ss=ss)

#for asset_update function
#因为paramiko 在 python3下执行报错，放弃远程执行命令的功能

@account.route('/actionn/<serverinfo>/',methods=['GET','POST'])
def asset_db_update(serverinfo):
	if request.method=="POST":
		action=request.form.get('delete')
		print(action)
		if not action:
			action=request.form.get('update')

		if action=='删除':
			# print(serverinfo)
			uu=db.session.query(models.Asset_db).filter(models.Asset_db.serverno==serverinfo).first().cpus.all()
			for ii in uu:
				db.session.query(models.Asset_db).filter(models.Asset_db.serverno==serverinfo).first().cpus.remove(ii)
			db.session.commit()

			uu=db.session.query(models.Asset_db).filter(models.Asset_db.serverno==serverinfo).first().memorys.all()
			for ii in uu:
				db.session.query(models.Asset_db).filter(models.Asset_db.serverno==serverinfo).first().memorys.remove(ii)
			db.session.commit()

			uu=db.session.query(models.Asset_db).filter(models.Asset_db.serverno==serverinfo).first().raids.all()
			for ii in uu:
				db.session.query(models.Asset_db).filter(models.Asset_db.serverno==serverinfo).first().raids.remove(ii)
			db.session.commit()

			uu=db.session.query(models.Asset_db).filter(models.Asset_db.serverno==serverinfo).first().disks.all()
			for ii in uu:
				db.session.query(models.Asset_db).filter(models.Asset_db.serverno==serverinfo).first().disks.remove(ii)
			db.session.commit()

			uu=db.session.query(models.Asset_db).filter(models.Asset_db.serverno==serverinfo).first().ethernets.all()
			for ii in uu:
				db.session.query(models.Asset_db).filter(models.Asset_db.serverno==serverinfo).first().ethernets.remove(ii)
			db.session.commit()

			uu=db.session.query(models.Asset_db).filter(models.Asset_db.serverno==serverinfo).first().fccards.all()
			for ii in uu:
				db.session.query(models.Asset_db).filter(models.Asset_db.serverno==serverinfo).first().fccards.remove(ii)
			db.session.commit()

			uu=db.session.query(models.Asset_db).filter(models.Asset_db.serverno==serverinfo).first().nvmes.all()
			for ii in uu:
				db.session.query(models.Asset_db).filter(models.Asset_db.serverno==serverinfo).first().nvmes.remove(ii)
			db.session.commit()

			db.session.query(models.Asset_db).filter(models.Asset_db.serverno==serverinfo).delete()
			db.session.commit()

		else:
			print(action)
			pass
			# Asset_update(serverinfo)

		return redirect('/asset_db_show/')



##define for api
##serverno list api
##一级api
@account.route('/api',methods=['GET'])
def get_api():
	allow_url=[
		'get http://127.0.0.1:5000/api/asset/v1.0/serverlist',
	]
	return jsonify({'url':allow_url})

##二级api
@account.route('/api/asset/v1.0/serverlist',methods=['GET'])
def get_serverno():
	tasks=db.session.query(models.Asset_db.serverno).all()
	# print(tasks)
	allow_url=[
		'get http://127.0.0.1:5000/api/asset/v1.0/<serverno>/detail',
		'post http://127.0.0.1:5000/api/asset/v1.0/<serverno>/update',
		'post http://127.0.0.1:5000/api/asset/v1.0/<serverno>/add',
	]
	return jsonify({'tasks':tasks,'url':allow_url})

##三级api
##assset detail  api
@account.route('/api/asset/v1.0/<serverno>/detail',methods=['GET'])
def get_detail(serverno):
	obj=db.session.query(models.Asset_db).filter(models.Asset_db.serverno==serverno).first()
	asset={}
	asset['serverno']=obj.serverno
	asset['ip_addr']=obj.ip_addr
	asset['os']=obj.os

	asset['cpus']=[]
	cpus={}
	for ii in obj.cpus.all():
		cpus['cpu_model']=ii.cpu_model
		cpus['cpu_maker']=ii.cpu_maker
		cpus['cpu_frequency']=ii.cpu_frequency
		cpus['cpu_tdp']=ii.cpu_tdp
		cpus['cpu_cores']=ii.cpu_cores
		cpus['cpu_threads']=ii.cpu_threads
		cpu_t=copy.deepcopy(cpus)
		asset['cpus'].append(cpu_t)

	asset['memorys']=[]
	MM={}
	for ii in obj.memorys.all():
		MM['model']=ii.mm_pn
		MM['serial']=ii.mm_sn
		MM['frequency']=ii.mm_frequency
		MM['capacity']=ii.mm_capacity
		MM['maker']=ii.mm_maker
		MM['slot']=ii.mm_slot
		temp=copy.deepcopy(MM)
		asset['memorys'].append(temp)

	print(asset['memorys'])


	asset['ethernet']=[]
	ethernets={}
	for ii in obj.ethernets.all():
		ethernets['e_model']=ii.e_model
		ethernets['e_sn']=ii.e_sn
		ethernets['e_fw']=ii.e_fw
		ethernets['e_maker']=ii.e_maker
		ethernets['e_portnum']=ii.e_portnum
		ethernets['e_porttype']=ii.e_porttype
		ethernets['e_qty']=ii.e_qty
		ethernet_t=copy.deepcopy(ethernets)
		asset['ethernet'].append(ethernet_t)

	asset['disk']=[]
	disks={}
	for ii in obj.disks.all():
		disks['d_model']=ii.d_model
		disks['d_fw']=ii.d_fw
		disks['d_maker']=ii.d_maker
		disks['d_type']=ii.d_type
		disks['d_qty']=ii.d_qty
		disks['d_slot']=ii.d_slot
		disks['d_sn']=ii.d_sn
		disks['d_slot']=ii.d_slot
		disk_t=copy.deepcopy(disks)
		asset['disk'].append(disk_t)

	asset['raid']=[]
	raids={}
	for ii in obj.raids.all():
		raids['r_model']=ii.r_model
		raids['r_sn']=ii.r_sn
		raids['r_fw']=ii.r_fw
		raids['r_maker']=ii.r_maker
		raids['r_cache']=ii.r_cache
		raids['r_bbu']=ii.r_bbu
		raid_t=copy.deepcopy(raids)
		asset['raid'].append(raid_t)
	return jsonify({'tasks':asset})


##running
@account.route('/api/asset/v1.0/<serverno>/update',methods=['POST'])
def update_serverno(serverno):
	print(request.json)
	print(type(request.json))
	# db.session.query(models.Asset_db).filter(models.Asset_db.serverno==serverno).update(request.json)
	# db.session.commit()
	return "OK"


##更新配置功能
class Asset_update:
	def __init__(self,data):
		self.data=data
		self.updte_action()

	def updte_action(self):
		ip_addr=self.data.get('ip_addr',None)
		if not ip_addr:
			return None
		line=db.session.query(models.Asset_db).filter(models.Asset_db.ip_addr==ip_addr).first()
		if not line:##新创建一条记录：
			print("第一次上报")
			line=models.Asset_db(serverno=self.data['serverno'],ip_addr=self.data['ip_addr'],user=self.data['user'],passwd=self.data['passwd'],os=self.data['os'])
			try:
				#cpu
				# print(type(result['cpu_info']))
				cpu_list=[]
				try:
					for cpuu in self.data['cpu_info']:
						obj=models.Cpu(
							cpu_model=cpuu[0],
							cpu_maker=cpuu[1],
							cpu_frequency=cpuu[2],
							cpu_cores=cpuu[3],
							cpu_threads=cpuu[4],
							cpu_tdp=cpuu[5],
							cpu_remark=cpuu[6],##for socket
						)
						cpu_list.append(obj)


					line.cpus=cpu_list
				except Exception as err:
					pass

				#memory
				mem_list=[]
				try:
					for mem in self.data['mem_info']:
						obj=models.Memory(
							mm_pn=mem[0],
							mm_sn=mem[1],
							mm_frequency=mem[2],
							mm_capacity=mem[3],
							mm_maker=mem[4],
							mm_slot=mem[5],
						)
						mem_list.append(obj)
					line.memorys=mem_list
				except Exception as err:
					pass


				##network card:
				e_list=[]
				try:
					# 'nic_info': [(' Intel Corporation Ethernet Connection X722 for 10GbE SFP+ (rev 09)', 'Intel', '3.1d 0x800008bb 255.65535.255', '4'), (' Intel Corporation 82599ES 10-Gigabit SFI/SFP+ Network Connection (rev 01)', 'Intel', '0x800006db', '2')],
					for nic in self.data['nic_info']:
						obj=models.Ethernet(e_model=nic[0],
									 e_maker=nic[1],
									 e_fw=nic[2],
									 e_portnum=nic[3],
									 e_qty=str(int(nic[3])/4 if int(nic[3])>=4 else 1),
									 e_porttype="1GbE/SFP 10GbE" if '722' in nic[0] else nic[4],
									 e_slot=nic[6],  #nic[5] for driver
									 )
						e_list.append(obj)
					line.ethernets=e_list
				except Exception as err:
					pass

				##raid card:
				r_list=[]
				try:
					# 'raidcard': ['AVAGO MegaRAID SAS 9361-16i', '4.740.00-8288', 'SK72771059', 'LSI'],
					rr=self.data['raidcard']
					obj=models.Raid(r_model=rr[0],
							 r_maker=rr[3],
							 r_sn=rr[2],
							 r_fw=rr[1],
							 r_cache=rr[4],
							 r_bbu=rr[5],
							 r_remark=rr[7],## for raid slot #nic[6] for driver
								 )
					r_list.append(obj)

					line.raids=r_list
				except Exception as err:
					pass

				##for disk:
				d_list=[]
				try:
					# 'nic_info': [(' Intel Corporation Ethernet Connection X722 for 10GbE SFP+ (rev 09)', 'Intel', '3.1d 0x800008bb 255.65535.255', '4'), (' Intel Corporation 82599ES 10-Gigabit SFI/SFP+ Network Connection (rev 01)', 'Intel', '0x800006db', '2')],
					for dd in self.data['disk']:
						obj=models.Disk(d_model=dd[0],
									 d_fw=dd[4],
									 d_maker=dd[2],
									 d_type=dd[3],
									 d_qty=dd[1],
									 d_slot=dd[5],
									 d_sn=dd[6],
									 d_remark=dd[7],
									 )
						d_list.append(obj)
					line.disks=d_list
				except Exception as err:
					pass

				line.status="Online"
				line.remark=datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
			except Exception as err:
				print(err)
			db.session.add(line)
			db.session.commit()

		else:
			print("第二次上报")
			try:
				#cpu
				# print(type(result['cpu_info']))
				cpu_list=[]
				try:
					for cpuu in self.data['cpu_info']:
						obj=models.Cpu(
							cpu_model=cpuu[0],
							cpu_maker=cpuu[1],
							cpu_frequency=cpuu[2],
							cpu_cores=cpuu[3],
							cpu_threads=cpuu[4],
							cpu_tdp=cpuu[5],
							cpu_remark=cpuu[6],##for socket
						)
						cpu_list.append(obj)

					#print(cpu_list)
					line.cpus=cpu_list
				except Exception as err:
					pass

				#memory
				mem_list=[]
				try:
					for mem in self.data['mem_info']:
						obj=models.Memory(
							mm_pn=mem[0],
							mm_sn=mem[1],
							mm_frequency=mem[2],
							mm_capacity=mem[3],
							mm_maker=mem[4],
							mm_slot=mem[5],
						)
						mem_list.append(obj)
					line.memorys=mem_list
				except Exception as err:
					pass


				##network card:
				e_list=[]
				try:
					# 'nic_info': [(' Intel Corporation Ethernet Connection X722 for 10GbE SFP+ (rev 09)', 'Intel', '3.1d 0x800008bb 255.65535.255', '4'), (' Intel Corporation 82599ES 10-Gigabit SFI/SFP+ Network Connection (rev 01)', 'Intel', '0x800006db', '2')],
					for nic in self.data['nic_info']:
						obj=models.Ethernet(e_model=nic[0],
									 e_maker=nic[1],
									 e_fw=nic[2],
									 e_portnum=nic[3],
									 e_qty=str(int(nic[3])/4 if int(nic[3])>=4 else 1),
									 e_porttype="1GbE/SFP 10GbE" if '722' in nic[0] else nic[4],
									 e_slot=nic[6],  #nic[5] for driver
									 )
						e_list.append(obj)
					line.ethernets=e_list
				except Exception as err:
					pass

				##raid card:
				r_list=[]
				try:
					# 'raidcard': ['AVAGO MegaRAID SAS 9361-16i', '4.740.00-8288', 'SK72771059', 'LSI'],
					rr=self.data['raidcard']
					obj=models.Raid(r_model=rr[0],
							 r_maker=rr[3],
							 r_sn=rr[2],
							 r_fw=rr[1],
							 r_cache=rr[4],
							 r_bbu=rr[5],
							 r_remark=rr[7],## for raid slot #nic[6] for driver
								 )
					r_list.append(obj)

					line.raids=r_list
				except Exception as err:
					pass

				##for disk:
				d_list=[]
				try:
					# 'nic_info': [(' Intel Corporation Ethernet Connection X722 for 10GbE SFP+ (rev 09)', 'Intel', '3.1d 0x800008bb 255.65535.255', '4'), (' Intel Corporation 82599ES 10-Gigabit SFI/SFP+ Network Connection (rev 01)', 'Intel', '0x800006db', '2')],
					for dd in self.data['disk']:
						obj=models.Disk(d_model=dd[0],
									 d_fw=dd[4],
									 d_maker=dd[2],
									 d_type=dd[3],
									 d_qty=dd[1],
									 d_slot=dd[5],
									 d_sn=dd[6],
									 d_remark=dd[7],
									 )
						d_list.append(obj)
					line.disks=d_list
				except Exception as err:
					pass

				line.status="Online"
				line.remark=datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
			except Exception as err:
				print(err)
			db.session.flush()
			db.session.commit()

@account.route('/api/asset/v1.0/update',methods=['POST'])
def update_asset():
	data=request.json
	Asset_update(data)
	# print(type(data))
	# print(data.get('nic_info',None))
	return "OK"
























# @account.route('/login')
# def login():
#     # 添加示例
#     """
#     db.session.add(models.Users(username='alex', pwd='123', gender=1))
#     db.session.commit()
#
#     obj = db.session.query(models.Users).filter(models.Users.id == 1).first()
#     print(obj)
#
#     PS: db.session和db.create_session
#     """
#     # db.session.add(models.Users(username='wupeiqi1', email='wupeiqi1@xx.com'))
#     # db.session.commit()
#     # db.session.close()
#     #
#     # db.session.add(models.Users(username='wupeiqi2', email='wupeiqi2@xx.com'))
#     # db.session.commit()
#     # db.session.close()
#     # db.session.add(models.Users(username='alex1',email='alex1@live.com'))
#     # db.session.commit()
#     # db.session.close()
#
#     # user_list = db.session.query(models.Users).all()
#     # db.session.close()
#     # for item in user_list:
#     #     print(item.username)
#
#
#     # 插入：操作数据库时不需要自己创建engine等操作，这些数据库帮忙完成了
#     # db.session.add(models.Users(username='thunder', email='thunder@163.com'))
#     # db.session.commit()
#
#     #查询：
#     user_list = db.session.query(models.Users).all()
#     print(user_list)
#
#     return 'login'
